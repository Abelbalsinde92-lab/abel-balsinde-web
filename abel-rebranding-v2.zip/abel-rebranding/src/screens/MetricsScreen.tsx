// ─────────────────────────────────────────────
//  MetricsScreen — Pestaña MÉTRICAS
//  Selector horizontal + gráfica vectorial limpia
// ─────────────────────────────────────────────
import React, { useState, useMemo } from 'react';
import {
  ScrollView,
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  Dimensions,
} from 'react-native';
import Svg, {
  Path,
  Line,
  Text as SvgText,
  Defs,
  LinearGradient,
  Stop,
  G,
} from 'react-native-svg';
import { COLORS, TYPOGRAPHY, SPACING, RADIUS } from '../constants/theme';
import { globalStyles } from '../constants/globalStyles';

// ── Types ────────────────────────────────────
type Variable = 'CARGA' | 'PULSO' | 'VO2 MAX';

interface DataPoint {
  label: string;
  value: number;
}

// ── Dataset ───────────────────────────────────
const datasets: Record<Variable, DataPoint[]> = {
  'CARGA': [
    { label: 'Sem 1', value: 6200 },
    { label: 'Sem 2', value: 7400 },
    { label: 'Sem 3', value: 6800 },
    { label: 'Sem 4', value: 8100 },
    { label: 'Sem 5', value: 7600 },
    { label: 'Sem 6', value: 9200 },
    { label: 'Sem 7', value: 8700 },
    { label: 'Sem 8', value: 10400 },
  ],
  'PULSO': [
    { label: 'Sem 1', value: 74 },
    { label: 'Sem 2', value: 78 },
    { label: 'Sem 3', value: 71 },
    { label: 'Sem 4', value: 82 },
    { label: 'Sem 5', value: 76 },
    { label: 'Sem 6', value: 80 },
    { label: 'Sem 7', value: 73 },
    { label: 'Sem 8', value: 77 },
  ],
  'VO2 MAX': [
    { label: 'Sem 1', value: 48 },
    { label: 'Sem 2', value: 49 },
    { label: 'Sem 3', value: 50 },
    { label: 'Sem 4', value: 49 },
    { label: 'Sem 5', value: 51 },
    { label: 'Sem 6', value: 52 },
    { label: 'Sem 7', value: 53 },
    { label: 'Sem 8', value: 55 },
  ],
};

const varColor: Record<Variable, string> = {
  'CARGA':   COLORS.sport,
  'PULSO':   COLORS.medical,
  'VO2 MAX': COLORS.streak,
};

const varUnit: Record<Variable, string> = {
  'CARGA':   'kg',
  'PULSO':   'bpm',
  'VO2 MAX': 'mL/kg/min',
};

// ── Chart ─────────────────────────────────────
interface PerformanceChartProps {
  data: DataPoint[];
  color: string;
  width: number;
  height?: number;
}

function buildPath(pts: { x: number; y: number }[]): string {
  if (pts.length < 2) return '';
  let d = `M ${pts[0].x} ${pts[0].y}`;
  for (let i = 0; i < pts.length - 1; i++) {
    const cp = (pts[i].x + pts[i + 1].x) / 2;
    d += ` C ${cp} ${pts[i].y} ${cp} ${pts[i + 1].y} ${pts[i + 1].x} ${pts[i + 1].y}`;
  }
  return d;
}

const PerformanceChart: React.FC<PerformanceChartProps> = ({
  data,
  color,
  width,
  height = 200,
}) => {
  const padL = 44;
  const padR = 16;
  const padT = 16;
  const padB = 32;
  const chartW = width - padL - padR;
  const chartH = height - padT - padB;

  const values = data.map(d => d.value);
  const minV = Math.min(...values);
  const maxV = Math.max(...values);
  const range = maxV - minV || 1;

  // Y-axis tick count
  const yTicks = 4;
  const yTickVals = Array.from({ length: yTicks + 1 }, (_, i) =>
    minV + (range / yTicks) * i,
  );

  const pts = data.map((d, i) => ({
    x: padL + (i / (data.length - 1)) * chartW,
    y: padT + ((maxV - d.value) / range) * chartH,
  }));

  const linePath = buildPath(pts);

  return (
    <Svg width={width} height={height}>
      <Defs>
        <LinearGradient id="chartGrad" x1="0" y1="0" x2="0" y2="1">
          <Stop offset="0" stopColor={color} stopOpacity={0.15} />
          <Stop offset="1" stopColor={color} stopOpacity={0} />
        </LinearGradient>
      </Defs>

      {/* ── Y-axis labels (attenuated) — no grid ── */}
      {yTickVals.map((v, i) => {
        const y = padT + ((maxV - v) / range) * chartH;
        const label = v >= 1000 ? `${(v / 1000).toFixed(1)}k` : Math.round(v).toString();
        return (
          <G key={i}>
            {/* Subtle tick line */}
            <Line
              x1={padL}
              y1={y}
              x2={padL + chartW}
              y2={y}
              stroke={COLORS.divider}
              strokeWidth={0.5}
            />
            <SvgText
              x={padL - 6}
              y={y + 4}
              fontSize={9}
              fill={COLORS.textSecondary}
              textAnchor="end"
              fontFamily="Menlo"
            >
              {label}
            </SvgText>
          </G>
        );
      })}

      {/* ── Gradient fill under line ── */}
      <Path
        d={`${linePath} L ${pts[pts.length - 1].x} ${padT + chartH} L ${pts[0].x} ${padT + chartH} Z`}
        fill="url(#chartGrad)"
      />

      {/* ── Main line — 2px clean vector stroke ── */}
      <Path
        d={linePath}
        stroke={color}
        strokeWidth={2}
        fill="none"
        strokeLinecap="round"
        strokeLinejoin="round"
      />

      {/* ── X-axis labels ── */}
      {data.map((d, i) => (
        <SvgText
          key={i}
          x={pts[i].x}
          y={padT + chartH + 18}
          fontSize={9}
          fill={COLORS.textSecondary}
          textAnchor="middle"
          fontFamily="Menlo"
        >
          {d.label}
        </SvgText>
      ))}
    </Svg>
  );
};

// ── Main Component ───────────────────────────
const { width: SCREEN_WIDTH } = Dimensions.get('window');
const CHART_WIDTH = SCREEN_WIDTH - SPACING.base * 2;

export const MetricsScreen: React.FC = () => {
  const [activeVar, setActiveVar] = useState<Variable>('CARGA');
  const data = datasets[activeVar];
  const color = varColor[activeVar];
  const unit = varUnit[activeVar];

  const latestValue = data[data.length - 1].value;
  const prevValue = data[data.length - 2].value;
  const delta = latestValue - prevValue;
  const deltaSign = delta >= 0 ? '+' : '';

  return (
    <ScrollView
      style={globalStyles.screen}
      contentContainerStyle={styles.content}
      showsVerticalScrollIndicator={false}
    >
      {/* ── Header ── */}
      <View style={styles.header}>
        <Text style={styles.title}>MÉTRICAS</Text>
      </View>

      {/* ── Variable selector — plain text, horizontal ── */}
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.selectorRow}
      >
        {(Object.keys(datasets) as Variable[]).map((v) => {
          const isActive = v === activeVar;
          return (
            <TouchableOpacity
              key={v}
              onPress={() => setActiveVar(v)}
              style={styles.selectorBtn}
            >
              <Text
                style={[
                  styles.selectorText,
                  isActive && { color: varColor[v] },
                ]}
              >
                {v}
              </Text>
              {isActive && (
                <View style={[styles.selectorIndicator, { backgroundColor: varColor[v] }]} />
              )}
            </TouchableOpacity>
          );
        })}
      </ScrollView>

      {/* ── Current value + delta ── */}
      <View style={styles.valueBlock}>
        <View>
          <Text style={[styles.currentValue, { color }]}>{latestValue}</Text>
          <Text style={styles.currentUnit}>{unit}</Text>
        </View>
        <View style={styles.deltaBlock}>
          <Text style={[styles.delta, { color: delta >= 0 ? COLORS.streak : COLORS.medical }]}>
            {deltaSign}{delta}
          </Text>
          <Text style={styles.deltaLabel}>vs semana anterior</Text>
        </View>
      </View>

      {/* ── Chart card ── */}
      <View style={styles.chartCard}>
        <PerformanceChart
          data={data}
          color={color}
          width={CHART_WIDTH}
          height={220}
        />
      </View>

      {/* ── Data table ── */}
      <View style={styles.tableCard}>
        <Text style={styles.tableLabel}>HISTÓRICO SEMANAL</Text>
        {[...data].reverse().map((row, i) => (
          <View key={i} style={[styles.tableRow, i > 0 && styles.tableRowBorder]}>
            <Text style={styles.tableDate}>{row.label}</Text>
            <Text style={[styles.tableVal, { color }]}>
              {row.value} <Text style={styles.tableUnit}>{unit}</Text>
            </Text>
          </View>
        ))}
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  content: {
    paddingBottom: SPACING.section,
  },
  header: {
    paddingHorizontal: SPACING.base,
    paddingTop: SPACING.xl,
    paddingBottom: SPACING.lg,
  },
  title: {
    fontSize: TYPOGRAPHY.size.xs,
    color: COLORS.textSecondary,
    letterSpacing: 1.4,
    fontWeight: '600',
  },
  // Selector
  selectorRow: {
    paddingHorizontal: SPACING.base,
    gap: SPACING.xl,
    marginBottom: SPACING.base,
  },
  selectorBtn: {
    alignItems: 'center',
    paddingBottom: SPACING.xs,
  },
  selectorText: {
    fontSize: TYPOGRAPHY.size.sm,
    fontWeight: '600',
    letterSpacing: 1.2,
    color: COLORS.textSecondary,
  },
  selectorIndicator: {
    height: 2,
    width: '100%',
    borderRadius: 1,
    marginTop: 4,
  },
  // Value block
  valueBlock: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-end',
    paddingHorizontal: SPACING.base,
    marginBottom: SPACING.base,
  },
  currentValue: {
    fontSize: TYPOGRAPHY.size.display,
    fontWeight: '700',
    letterSpacing: -1.5,
  },
  currentUnit: {
    fontSize: TYPOGRAPHY.size.sm,
    color: COLORS.textSecondary,
    marginTop: 2,
  },
  deltaBlock: {
    alignItems: 'flex-end',
  },
  delta: {
    fontSize: TYPOGRAPHY.size.xl,
    fontWeight: '700',
    letterSpacing: -0.5,
  },
  deltaLabel: {
    fontSize: TYPOGRAPHY.size.xs,
    color: COLORS.textSecondary,
    marginTop: 2,
  },
  // Chart
  chartCard: {
    marginHorizontal: SPACING.base,
    backgroundColor: COLORS.card,
    borderWidth: 1,
    borderColor: COLORS.cardBorder,
    borderRadius: RADIUS.md,
    overflow: 'hidden',
    marginBottom: SPACING.sm,
    padding: SPACING.sm,
  },
  // Table
  tableCard: {
    marginHorizontal: SPACING.base,
    backgroundColor: COLORS.card,
    borderWidth: 1,
    borderColor: COLORS.cardBorder,
    borderRadius: RADIUS.md,
    overflow: 'hidden',
  },
  tableLabel: {
    fontSize: TYPOGRAPHY.size.xs,
    color: COLORS.textSecondary,
    letterSpacing: 1.4,
    fontWeight: '600',
    padding: SPACING.md,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.divider,
  },
  tableRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: SPACING.md,
    paddingHorizontal: SPACING.md,
  },
  tableRowBorder: {
    borderTopWidth: 1,
    borderTopColor: COLORS.divider,
  },
  tableDate: {
    fontSize: TYPOGRAPHY.size.sm,
    color: COLORS.textSecondary,
    fontFamily: 'Menlo',
  },
  tableVal: {
    fontSize: TYPOGRAPHY.size.base,
    fontWeight: '700',
  },
  tableUnit: {
    fontSize: TYPOGRAPHY.size.xs,
    color: COLORS.textSecondary,
    fontWeight: '400',
  },
});
