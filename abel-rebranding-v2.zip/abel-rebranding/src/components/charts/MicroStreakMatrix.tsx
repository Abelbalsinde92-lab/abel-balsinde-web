// ─────────────────────────────────────────────
//  MicroStreakMatrix — Matriz de racha en puntos
//  Tarjeta 3: Constancia (streak green)
// ─────────────────────────────────────────────
import React from 'react';
import Svg, { Circle, Rect } from 'react-native-svg';
import { COLORS } from '../../constants/theme';

interface MicroStreakMatrixProps {
  /** Array of booleans: true = day completed */
  data: boolean[];
  columns?: number;
  width?: number;
  height?: number;
  color?: string;
}

export const MicroStreakMatrix: React.FC<MicroStreakMatrixProps> = ({
  data,
  columns = 10,
  width = 120,
  height = 48,
  color = COLORS.streak,
}) => {
  const rows = Math.ceil(data.length / columns);
  const dotSize = Math.min(
    (width - (columns - 1) * 3) / columns,
    (height - (rows - 1) * 3) / rows,
  );
  const gap = 3;

  const cells = data.slice(0, columns * rows);

  return (
    <Svg width={width} height={height} viewBox={`0 0 ${width} ${height}`}>
      {cells.map((active, idx) => {
        const col = idx % columns;
        const row = Math.floor(idx / columns);
        const cx = col * (dotSize + gap) + dotSize / 2;
        const cy = row * (dotSize + gap) + dotSize / 2;
        return (
          <Circle
            key={idx}
            cx={cx}
            cy={cy}
            r={dotSize / 2}
            fill={active ? color : '#1F1F24'}
            opacity={active ? 1 : 0.6}
          />
        );
      })}
    </Svg>
  );
};
