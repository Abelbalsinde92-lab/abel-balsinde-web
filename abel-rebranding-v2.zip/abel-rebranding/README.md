# Abel Balsinde — Client Rebranding v2.0

**Design System: Modo Oscuro Estricto · Minimalista Técnico**

---

## Estructura de Archivos

```
src/
├── App.tsx                          # Root: orquesta navegación entre pestañas
├── constants/
│   ├── theme.ts                     # Paleta, tipografía, spacing, tokens
│   └── globalStyles.ts              # StyleSheet global reutilizable
├── components/
│   ├── ui/
│   │   ├── TopTabBar.tsx            # Menú 3 tabs texto plano + indicador 2px azul
│   │   ├── HomeHeader.tsx           # "Hola, Abel" + fecha en gris, fondo negro puro
│   │   └── DashboardCard.tsx        # Tarjeta métrica tappable → navega a pestaña
│   └── charts/
│       ├── MicroBarChart.tsx        # Barras verticales azules (Entrenamiento)
│       ├── MicroLineChart.tsx       # Línea spline fina coral (Salud)
│       └── MicroStreakMatrix.tsx    # Matriz de racha en puntos verdes (Constancia)
└── screens/
    ├── TrainingScreen.tsx           # Pestaña ENTRENAMIENTO — 3 DashboardCards + resumen sesión
    ├── HealthScreen.tsx             # Pestaña SALUD — formularios oscuros + diagnóstico clínico
    └── MetricsScreen.tsx            # Pestaña MÉTRICAS — selector variable + gráfica vectorial
```

---

## Sistema de Diseño

### Paleta
| Token          | Hex       | Uso                        |
|----------------|-----------|----------------------------|
| `bg`           | `#000000` | Fondo general              |
| `card`         | `#121214` | Tarjetas y secciones       |
| `cardBorder`   | `#1F1F24` | Bordes de tarjeta          |
| `divider`      | `#16161A` | Líneas divisorias          |
| `textPrimary`  | `#FFFFFF` | Texto principal            |
| `textSecondary`| `#8E8E93` | Labels, ejes, subtextos    |
| `sport`        | `#00A3FF` | Datos de entrenamiento     |
| `medical`      | `#FF5A5A` | Datos de salud             |
| `streak`       | `#00E676` | Datos de constancia        |

### Tipografía
- **Geométrica de sistema** (SF Pro en iOS / Roboto en Android)
- **Monospace**: `Menlo` para ejes de gráficas e índices clínicos
- **Line-height clínico**: 24px para textos de diagnóstico
- **Letra espaciada**: 1.2–1.4 para labels en uppercase

### Principios
- **Sin iconos decorativos** — la identidad visual viene de datos y tipografía
- **Sin fondos circulares ni óvalos** en botones de navegación
- **Colores funcionales** asignados semánticamente: azul=deporte, coral=médico, verde=constancia

---

## Instalación

```bash
# 1. Clonar y navegar
cd abel-balsinde-web/client

# 2. Reemplazar con esta estructura refactorizada
# (copiar carpeta src/ y archivos de config sobre el proyecto existente)

# 3. Instalar dependencias
npm install

# 4. Verificar tipos
npm run type-check

# 5. Arrancar
npm start
```

### Dependencias clave
```
react-native-svg     # Gráficas vectoriales (MicroBarChart, MicroLineChart, MicroStreakMatrix, PerformanceChart)
expo                 # Runtime y build system
```

---

## Componentes Clave

### TopTabBar
- 3 pestañas: **ENTRENAMIENTO · SALUD · MÉTRICAS**
- Tab activa: texto `#FFFFFF` + indicador inferior `2px` en `#00A3FF`
- Tabs inactivas: texto `#8E8E93`
- Animación del indicador: `Animated.timing` 200ms

### DashboardCards (Home)
- **Card 1**: `MicroBarChart` azul → navega a ENTRENAMIENTO
- **Card 2**: `MicroLineChart` spline coral → navega a SALUD  
- **Card 3**: `MicroStreakMatrix` puntos verdes → navega a MÉTRICAS

### HealthScreen
- Toggle **DATOS / DIAGNÓSTICO**
- Filas: Métrica (gris) | Valor Bold (blanco) | Estado `[ÓPTIMO]` (color funcional)
- Vista diagnóstico: texto clínico continuo, line-height 24px, sin iconos

### MetricsScreen
- Selector horizontal: **CARGA · PULSO · VO2 MAX**
- Gráfica: trazos vectoriales 2px, sin cuadrícula, solo etiquetas atenuadas en ejes
- Gradiente suave bajo la línea para profundidad visual sin ruido

---

## Notas de Producción

1. **react-native-svg** debe estar en el `metro.config.js` si se usa Expo con bare workflow.
2. Los datos de las gráficas son mock — conectar a la API existente reemplazando los arrays en cada screen.
3. Para iOS: añadir `NSFaceIDUsageDescription` si se añade autenticación biométrica en futuras iteraciones.
4. El componente `HomeHeader` calcula `formatDate()` una sola vez por render con `useMemo`.
