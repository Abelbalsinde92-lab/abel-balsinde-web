// ─────────────────────────────────────────────
//  App.tsx — Root Component
//  Abel Balsinde · Design System v2.0
//  Dark Mode Estricto · Minimalista Técnico
// ─────────────────────────────────────────────
import React, { useState, useCallback } from 'react';
import { View, StyleSheet, SafeAreaView, StatusBar } from 'react-native';
import { TopTabBar } from './components/ui/TopTabBar';
import { TrainingScreen } from './screens/TrainingScreen';
import { HealthScreen } from './screens/HealthScreen';
import { MetricsScreen } from './screens/MetricsScreen';
import { COLORS } from './constants/theme';
import type { TabKey } from './constants/theme';

export default function App() {
  const [activeTab, setActiveTab] = useState<TabKey>('training');

  const handleNavigate = useCallback((tab: TabKey) => {
    setActiveTab(tab);
  }, []);

  const renderScreen = () => {
    switch (activeTab) {
      case 'training': return <TrainingScreen onNavigate={handleNavigate} />;
      case 'health':   return <HealthScreen />;
      case 'metrics':  return <MetricsScreen />;
    }
  };

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar barStyle="light-content" backgroundColor={COLORS.bg} />
      <View style={styles.root}>
        <TopTabBar activeTab={activeTab} onTabPress={handleNavigate} />
        {renderScreen()}
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: COLORS.bg,
  },
  root: {
    flex: 1,
    backgroundColor: COLORS.bg,
  },
});
