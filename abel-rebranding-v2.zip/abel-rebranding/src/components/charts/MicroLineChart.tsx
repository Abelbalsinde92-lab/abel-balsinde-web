// ─────────────────────────────────────────────
//  MicroLineChart — Línea spline fina coral
//  Tarjeta 2: Salud (medical coral)
// ─────────────────────────────────────────────
import React from 'react';
import Svg, { Path, Circle } from 'react-native-svg';
import { COLORS } from '../../constants/theme';

interface MicroLineChartProps {
  data: number[]; // values 0–100
  width?: number;
  height?: number;
  color?: string;
}

/**
 * Builds a smooth cubic bezier path from data points.
 */
function buildSplinePath(
  pts: { x: number; y: number }[],
): string {
  if (pts.length < 2) return '';
  let d = `M ${pts[0].x} ${pts[0].y}`;
  for (let i = 0; i < pts.length - 1; i++) {
    const curr = pts[i];
    const next = pts[i + 1];
    const cpX = (curr.x + next.x) / 2;
    d += ` C ${cpX} ${curr.y} ${cpX} ${next.y} ${next.x} ${next.y}`;
  }
  return d;
}

export const MicroLineChart: React.FC<MicroLineChartProps> = ({
  data,
  width = 120,
  height = 48,
  color = COLORS.medical,
}) => {
  const max = Math.max(...data, 1);
  const min = Math.min(...data);
  const range = max - min || 1;
  const padV = 6;

  const points = data.map((val, i) => ({
    x: (i / (data.length - 1)) * width,
    y: padV + ((max - val) / range) * (height - padV * 2),
  }));

  const path = buildSplinePath(points);
  const lastPt = points[points.length - 1];

  return (
    <Svg width={width} height={height} viewBox={`0 0 ${width} ${height}`}>
      {/* Spline stroke */}
      <Path
        d={path}
        stroke={color}
        strokeWidth={1.5}
        fill="none"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      {/* Terminal dot */}
      <Circle
        cx={lastPt.x}
        cy={lastPt.y}
        r={3}
        fill={color}
      />
    </Svg>
  );
};
