// ─────────────────────────────────────────────
//  GLOBAL STYLES — Abel Balsinde Design System
// ─────────────────────────────────────────────
import { StyleSheet } from 'react-native';
import { COLORS, TYPOGRAPHY, SPACING, RADIUS } from '../constants/theme';

export const globalStyles = StyleSheet.create({
  // ── Layout ──────────────────────────────────
  screen: {
    flex: 1,
    backgroundColor: COLORS.bg,
  },
  safeArea: {
    flex: 1,
    backgroundColor: COLORS.bg,
  },

  // ── Cards ───────────────────────────────────
  card: {
    backgroundColor: COLORS.card,
    borderWidth: 1,
    borderColor: COLORS.cardBorder,
    borderRadius: RADIUS.md,
    padding: SPACING.base,
  },
  cardNoPad: {
    backgroundColor: COLORS.card,
    borderWidth: 1,
    borderColor: COLORS.cardBorder,
    borderRadius: RADIUS.md,
  },

  // ── Dividers ────────────────────────────────
  divider: {
    height: 1,
    backgroundColor: COLORS.divider,
  },

  // ── Typography ──────────────────────────────
  textPrimary: {
    color: COLORS.textPrimary,
    fontWeight: TYPOGRAPHY.fontFamily.regular,
    fontSize: TYPOGRAPHY.size.base,
  },
  textSecondary: {
    color: COLORS.textSecondary,
    fontSize: TYPOGRAPHY.size.sm,
  },
  textLabel: {
    color: COLORS.textSecondary,
    fontSize: TYPOGRAPHY.size.xs,
    letterSpacing: 1.2,
    textTransform: 'uppercase',
  },
  textValue: {
    color: COLORS.textPrimary,
    fontWeight: '700',
    fontSize: TYPOGRAPHY.size.md,
  },
  textDisplay: {
    color: COLORS.textPrimary,
    fontWeight: '700',
    fontSize: TYPOGRAPHY.size.display,
    letterSpacing: -1,
  },
  textClinical: {
    color: COLORS.textPrimary,
    fontSize: TYPOGRAPHY.size.base,
    lineHeight: TYPOGRAPHY.lineHeight.clinical,
    fontWeight: '400',
  },

  // ── Row utilities ───────────────────────────
  row: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  rowBetween: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  spacer: { flex: 1 },
});
