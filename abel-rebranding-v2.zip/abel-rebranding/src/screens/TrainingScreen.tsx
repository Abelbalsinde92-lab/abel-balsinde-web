// ─────────────────────────────────────────────
//  TrainingScreen — Pestaña ENTRENAMIENTO
//  Tres DashboardCards con micro-gráficas planas
// ─────────────────────────────────────────────
import React from 'react';
import { ScrollView, View, Text, StyleSheet } from 'react-native';
import { HomeHeader } from '../components/ui/HomeHeader';
import { DashboardCard } from '../components/ui/DashboardCard';
import { MicroBarChart } from '../components/charts/MicroBarChart';
import { MicroLineChart } from '../components/charts/MicroLineChart';
import { MicroStreakMatrix } from '../components/charts/MicroStreakMatrix';
import { COLORS, SPACING, TYPOGRAPHY } from '../constants/theme';
import { globalStyles } from '../constants/globalStyles';
import type { TabKey } from '../constants/theme';

// ── Mock Data ─────────────────────────────────
const trainingVolume = [40, 65, 55, 80, 70, 90, 60, 75, 85, 95, 50, 88];
const heartRateHistory = [72, 78, 74, 80, 76, 82, 79, 85, 88, 83, 77, 81];
const streakDays = [
  true, true, true, false, true, true, true,
  true, false, true, true, true, true, true,
  true, true, false, false, true, true,
  true, true, true, true, false, true, true,
  true, true, true,
];

interface TrainingScreenProps {
  onNavigate: (tab: TabKey) => void;
}

export const TrainingScreen: React.FC<TrainingScreenProps> = ({ onNavigate }) => (
  <ScrollView
    style={globalStyles.screen}
    contentContainerStyle={styles.content}
    showsVerticalScrollIndicator={false}
  >
    <HomeHeader />

    {/* ── Card grid (3 cards in 2-1 layout) ── */}
    <View style={styles.cardRow}>
      <DashboardCard
        label="Carga"
        value="87"
        unit="kg"
        accentColor={COLORS.sport}
        targetTab="training"
        onPress={onNavigate}
        chart={
          <MicroBarChart
            data={trainingVolume}
            width={120}
            height={44}
            color={COLORS.sport}
          />
        }
      />
      <DashboardCard
        label="Pulso"
        value="81"
        unit="bpm"
        accentColor={COLORS.medical}
        targetTab="health"
        onPress={onNavigate}
        chart={
          <MicroLineChart
            data={heartRateHistory}
            width={120}
            height={44}
            color={COLORS.medical}
          />
        }
      />
    </View>

    <View style={styles.cardFull}>
      <DashboardCard
        label="Constancia"
        value="26"
        unit="días"
        accentColor={COLORS.streak}
        targetTab="metrics"
        onPress={onNavigate}
        chart={
          <MicroStreakMatrix
            data={streakDays}
            columns={15}
            width={280}
            height={36}
            color={COLORS.streak}
          />
        }
      />
    </View>

    {/* ── Last session summary ── */}
    <View style={styles.section}>
      <Text style={styles.sectionLabel}>ÚLTIMA SESIÓN</Text>
      {[
        { metric: 'Duración',    value: '58 min',   color: COLORS.sport },
        { metric: 'Volumen',     value: '12.400 kg', color: COLORS.sport },
        { metric: 'FC Media',    value: '141 bpm',   color: COLORS.medical },
        { metric: 'Calorías',   value: '620 kcal',  color: COLORS.streak },
      ].map((row) => (
        <MetricRow key={row.metric} {...row} />
      ))}
    </View>
  </ScrollView>
);

// ── Local sub-component ───────────────────────
interface MetricRowProps {
  metric: string;
  value: string;
  color: string;
}

const MetricRow: React.FC<MetricRowProps> = ({ metric, value, color }) => (
  <View style={rowStyles.row}>
    <Text style={rowStyles.metric}>{metric}</Text>
    <Text style={[rowStyles.value, { color }]}>{value}</Text>
  </View>
);

const styles = StyleSheet.create({
  content: {
    paddingBottom: SPACING.section,
  },
  cardRow: {
    flexDirection: 'row',
    gap: SPACING.sm,
    paddingHorizontal: SPACING.base,
    marginBottom: SPACING.sm,
  },
  cardFull: {
    paddingHorizontal: SPACING.base,
    marginBottom: SPACING.base,
  },
  section: {
    marginHorizontal: SPACING.base,
    backgroundColor: COLORS.card,
    borderWidth: 1,
    borderColor: COLORS.cardBorder,
    borderRadius: 10,
    overflow: 'hidden',
  },
  sectionLabel: {
    fontSize: TYPOGRAPHY.size.xs,
    color: COLORS.textSecondary,
    letterSpacing: 1.4,
    fontWeight: '600',
    padding: SPACING.md,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.divider,
  },
});

const rowStyles = StyleSheet.create({
  row: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: SPACING.md,
    paddingHorizontal: SPACING.md,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.divider,
  },
  metric: {
    fontSize: TYPOGRAPHY.size.sm,
    color: COLORS.textSecondary,
  },
  value: {
    fontSize: TYPOGRAPHY.size.base,
    fontWeight: '700',
  },
});
