// ─────────────────────────────────────────────
//  MicroBarChart — Barras verticales azules
//  Tarjeta 1: Entrenamiento (sport blue)
// ─────────────────────────────────────────────
import React from 'react';
import { View, StyleSheet } from 'react-native';
import Svg, { Rect } from 'react-native-svg';
import { COLORS } from '../../constants/theme';

interface MicroBarChartProps {
  data: number[]; // values 0–100
  width?: number;
  height?: number;
  color?: string;
}

export const MicroBarChart: React.FC<MicroBarChartProps> = ({
  data,
  width = 120,
  height = 48,
  color = COLORS.sport,
}) => {
  const barCount = data.length;
  const gap = 3;
  const barWidth = (width - gap * (barCount - 1)) / barCount;
  const max = Math.max(...data, 1);

  return (
    <Svg width={width} height={height} viewBox={`0 0 ${width} ${height}`}>
      {data.map((val, i) => {
        const barHeight = (val / max) * height;
        const x = i * (barWidth + gap);
        const y = height - barHeight;
        return (
          <Rect
            key={i}
            x={x}
            y={y}
            width={barWidth}
            height={barHeight}
            rx={2}
            fill={color}
            opacity={0.9}
          />
        );
      })}
    </Svg>
  );
};
