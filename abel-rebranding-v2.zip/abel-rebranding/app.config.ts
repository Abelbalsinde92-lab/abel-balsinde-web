import { ExpoConfig } from 'expo/config';

const config: ExpoConfig = {
  name: 'Abel Balsinde',
  slug: 'abel-balsinde',
  version: '2.0.0',
  orientation: 'portrait',
  backgroundColor: '#000000',
  userInterfaceStyle: 'dark',
  ios: {
    supportsTablet: false,
    bundleIdentifier: 'com.abelbalsinde.app',
    infoPlist: {
      UIStatusBarStyle: 'UIStatusBarStyleLightContent',
    },
  },
  android: {
    adaptiveIcon: {
      backgroundColor: '#000000',
    },
    package: 'com.abelbalsinde.app',
    statusBar: {
      style: 'light',
      backgroundColor: '#000000',
    },
  },
  plugins: [
    'expo-router',
    [
      'react-native-svg',
      { android: { useAndroidX: true } },
    ],
  ],
};

export default config;
