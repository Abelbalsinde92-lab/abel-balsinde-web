// ─────────────────────────────────────────────
//  DashboardCard — Tarjeta métrica con micro-gráfica
//  Tappable → navega directamente a su pestaña
// ─────────────────────────────────────────────
import React from 'react';
import {
  TouchableOpacity,
  View,
  Text,
  StyleSheet,
} from 'react-native';
import { COLORS, TYPOGRAPHY, SPACING, RADIUS, TabKey } from '../../constants/theme';

interface DashboardCardProps {
  label: string;
  value: string;
  unit: string;
  accentColor: string;
  chart: React.ReactNode;
  targetTab: TabKey;
  onPress: (tab: TabKey) => void;
}

export const DashboardCard: React.FC<DashboardCardProps> = ({
  label,
  value,
  unit,
  accentColor,
  chart,
  targetTab,
  onPress,
}) => (
  <TouchableOpacity
    style={styles.card}
    onPress={() => onPress(targetTab)}
    activeOpacity={0.75}
  >
    {/* Header row */}
    <View style={styles.header}>
      <Text style={styles.label}>{label}</Text>
      {/* Accent dot — zero icons */}
      <View style={[styles.accentDot, { backgroundColor: accentColor }]} />
    </View>

    {/* Value */}
    <View style={styles.valueRow}>
      <Text style={styles.value}>{value}</Text>
      <Text style={[styles.unit, { color: accentColor }]}>{unit}</Text>
    </View>

    {/* Micro-chart */}
    <View style={styles.chartArea}>{chart}</View>
  </TouchableOpacity>
);

const styles = StyleSheet.create({
  card: {
    flex: 1,
    backgroundColor: COLORS.card,
    borderWidth: 1,
    borderColor: COLORS.cardBorder,
    borderRadius: RADIUS.md,
    padding: SPACING.md,
    minHeight: 140,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: SPACING.xs,
  },
  label: {
    fontSize: TYPOGRAPHY.size.xs,
    color: COLORS.textSecondary,
    letterSpacing: 1.2,
    textTransform: 'uppercase',
    fontWeight: '600',
  },
  accentDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
  },
  valueRow: {
    flexDirection: 'row',
    alignItems: 'baseline',
    gap: 4,
    marginBottom: SPACING.md,
  },
  value: {
    fontSize: TYPOGRAPHY.size.xl,
    fontWeight: '700',
    color: COLORS.textPrimary,
    letterSpacing: -0.5,
  },
  unit: {
    fontSize: TYPOGRAPHY.size.sm,
    fontWeight: '600',
  },
  chartArea: {
    marginTop: 'auto',
  },
});
