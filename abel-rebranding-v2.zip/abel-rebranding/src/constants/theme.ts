// ─────────────────────────────────────────────
//  ABEL BALSINDE — DESIGN SYSTEM v2.0
//  Modo Oscuro Estricto · Minimalista Técnico
// ─────────────────────────────────────────────

export const COLORS = {
  // Backgrounds
  bg: '#000000',
  card: '#121214',
  cardBorder: '#1F1F24',
  divider: '#16161A',

  // Text
  textPrimary: '#FFFFFF',
  textSecondary: '#8E8E93',

  // Functional Data Colors (NO icons)
  sport: '#00A3FF',   // Azul  — Entrenamiento
  medical: '#FF5A5A', // Coral — Salud
  streak: '#00E676',  // Verde — Constancia / Métricas

  // Tab indicator
  tabActive: '#FFFFFF',
  tabIndicator: '#00A3FF',
  tabInactive: '#8E8E93',
} as const;

export const TYPOGRAPHY = {
  // System-level geometric sans (SF Pro / equivalent)
  fontFamily: {
    regular: 'System',
    medium: '500',
    semibold: '600',
    bold: '700',
    mono: 'Menlo',
  },
  lineHeight: {
    clinical: 24, // Clinical / diagnosis text
    tight: 18,
    normal: 22,
  },
  size: {
    xs: 11,
    sm: 13,
    base: 15,
    md: 17,
    lg: 20,
    xl: 24,
    xxl: 32,
    display: 40,
  },
} as const;

export const SPACING = {
  xs: 4,
  sm: 8,
  md: 12,
  base: 16,
  lg: 20,
  xl: 24,
  xxl: 32,
  section: 40,
} as const;

export const RADIUS = {
  sm: 6,
  md: 10,
  lg: 14,
} as const;

export type TabKey = 'training' | 'health' | 'metrics';

export const TABS: { key: TabKey; label: string }[] = [
  { key: 'training', label: 'ENTRENAMIENTO' },
  { key: 'health',   label: 'SALUD' },
  { key: 'metrics',  label: 'MÉTRICAS' },
];
