// ─────────────────────────────────────────────
//  TopTabBar — Texto plano, sin fondos ni óvalos
//  Indicador inferior 2px en azul sport
// ─────────────────────────────────────────────
import React from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  Animated,
  useRef,
  useEffect,
} from 'react-native';
import { COLORS, TYPOGRAPHY, SPACING, TABS, TabKey } from '../constants/theme';

interface TopTabBarProps {
  activeTab: TabKey;
  onTabPress: (tab: TabKey) => void;
}

export const TopTabBar: React.FC<TopTabBarProps> = ({ activeTab, onTabPress }) => {
  const indicatorAnim = useRef(new Animated.Value(0)).current;

  const tabIndex = TABS.findIndex(t => t.key === activeTab);

  useEffect(() => {
    Animated.timing(indicatorAnim, {
      toValue: tabIndex,
      duration: 200,
      useNativeDriver: false,
    }).start();
  }, [tabIndex]);

  return (
    <View style={styles.container}>
      {/* ── Tab labels ── */}
      <View style={styles.tabRow}>
        {TABS.map((tab) => {
          const isActive = tab.key === activeTab;
          return (
            <TouchableOpacity
              key={tab.key}
              style={styles.tab}
              onPress={() => onTabPress(tab.key)}
              activeOpacity={0.7}
            >
              <Text
                style={[
                  styles.tabText,
                  isActive ? styles.tabTextActive : styles.tabTextInactive,
                ]}
              >
                {tab.label}
              </Text>
            </TouchableOpacity>
          );
        })}
      </View>

      {/* ── 2px indicator bar ── */}
      <View style={styles.indicatorTrack}>
        <Animated.View
          style={[
            styles.indicatorBar,
            {
              left: indicatorAnim.interpolate({
                inputRange: [0, 1, 2],
                outputRange: ['0%', '33.33%', '66.66%'],
              }),
              width: '33.33%',
            },
          ]}
        />
      </View>

      {/* ── Bottom divider ── */}
      <View style={styles.divider} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: COLORS.bg,
    paddingTop: SPACING.sm,
  },
  tabRow: {
    flexDirection: 'row',
  },
  tab: {
    flex: 1,
    alignItems: 'center',
    paddingVertical: SPACING.sm,
    paddingHorizontal: SPACING.xs,
  },
  tabText: {
    fontSize: TYPOGRAPHY.size.xs,
    letterSpacing: 1.4,
    fontWeight: '600',
  },
  tabTextActive: {
    color: COLORS.tabActive,
  },
  tabTextInactive: {
    color: COLORS.tabInactive,
  },
  indicatorTrack: {
    height: 2,
    position: 'relative',
  },
  indicatorBar: {
    height: 2,
    backgroundColor: COLORS.tabIndicator,
    position: 'absolute',
  },
  divider: {
    height: 1,
    backgroundColor: COLORS.divider,
  },
});
