// ─────────────────────────────────────────────
//  HealthScreen — Pestaña SALUD
//  Formularios oscuros + Vista Diagnóstico Clínico
// ─────────────────────────────────────────────
import React, { useState } from 'react';
import {
  ScrollView,
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
} from 'react-native';
import { COLORS, TYPOGRAPHY, SPACING, RADIUS } from '../constants/theme';
import { globalStyles } from '../constants/globalStyles';

// ── Types ────────────────────────────────────
type HealthStatus = 'ÓPTIMO' | 'NORMAL' | 'ATENCIÓN' | 'CRÍTICO';
type ViewMode = 'data' | 'diagnosis';

interface HealthMetric {
  metric: string;
  value: string;
  unit: string;
  status: HealthStatus;
}

// ── Mock Data ─────────────────────────────────
const vitals: HealthMetric[] = [
  { metric: 'Presión Arterial', value: '118/76',  unit: 'mmHg', status: 'ÓPTIMO'  },
  { metric: 'FC en Reposo',     value: '58',      unit: 'bpm',  status: 'ÓPTIMO'  },
  { metric: 'Glucosa',          value: '94',      unit: 'mg/dL',status: 'NORMAL'  },
  { metric: 'Hemoglobina',      value: '14.2',    unit: 'g/dL', status: 'NORMAL'  },
  { metric: 'Cortisol',         value: '21.4',    unit: 'μg/dL',status: 'ATENCIÓN'},
  { metric: 'Vitamina D',       value: '28',      unit: 'ng/mL',status: 'ATENCIÓN'},
  { metric: 'Testosterona',     value: '612',     unit: 'ng/dL',status: 'ÓPTIMO'  },
  { metric: 'PCR',              value: '0.4',     unit: 'mg/L', status: 'ÓPTIMO'  },
];

const statusColor: Record<HealthStatus, string> = {
  'ÓPTIMO':   COLORS.streak,
  'NORMAL':   COLORS.sport,
  'ATENCIÓN': '#FFB340',
  'CRÍTICO':  COLORS.medical,
};

// ── Main Component ───────────────────────────
export const HealthScreen: React.FC = () => {
  const [view, setView] = useState<ViewMode>('data');

  return (
    <ScrollView
      style={globalStyles.screen}
      contentContainerStyle={styles.content}
      showsVerticalScrollIndicator={false}
    >
      {/* ── Section header ── */}
      <View style={styles.header}>
        <Text style={styles.title}>SALUD</Text>
        {/* Toggle: Data / Diagnosis */}
        <View style={styles.toggle}>
          <TouchableOpacity
            style={[styles.toggleBtn, view === 'data' && styles.toggleBtnActive]}
            onPress={() => setView('data')}
          >
            <Text style={[styles.toggleText, view === 'data' && styles.toggleTextActive]}>
              DATOS
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.toggleBtn, view === 'diagnosis' && styles.toggleBtnActive]}
            onPress={() => setView('diagnosis')}
          >
            <Text style={[styles.toggleText, view === 'diagnosis' && styles.toggleTextActive]}>
              DIAGNÓSTICO
            </Text>
          </TouchableOpacity>
        </View>
      </View>

      {view === 'data' ? <DataView /> : <DiagnosisView />}
    </ScrollView>
  );
};

// ── Data View ─────────────────────────────────
const DataView: React.FC = () => (
  <View>
    <View style={styles.cardSection}>
      <Text style={styles.sectionLabel}>PARÁMETROS VITALES</Text>
      {vitals.map((item, index) => (
        <React.Fragment key={item.metric}>
          <HealthMetricRow {...item} />
          {index < vitals.length - 1 && <View style={styles.rowDivider} />}
        </React.Fragment>
      ))}
    </View>

    {/* ── Blood markers summary ── */}
    <View style={[styles.cardSection, styles.marginTop]}>
      <Text style={styles.sectionLabel}>RESUMEN ANALÍTICA</Text>
      <View style={styles.summaryGrid}>
        {[
          { label: 'VALORES OK',     count: 5, color: COLORS.streak  },
          { label: 'EN REVISIÓN',    count: 2, color: '#FFB340'       },
          { label: 'CRÍTICOS',       count: 0, color: COLORS.medical  },
        ].map(({ label, count, color }) => (
          <View key={label} style={styles.summaryCell}>
            <Text style={[styles.summaryCount, { color }]}>{count}</Text>
            <Text style={styles.summaryLabel}>{label}</Text>
          </View>
        ))}
      </View>
    </View>
  </View>
);

// ── Health Metric Row ─────────────────────────
const HealthMetricRow: React.FC<HealthMetric> = ({ metric, value, unit, status }) => (
  <View style={rowStyles.row}>
    <Text style={rowStyles.metric}>{metric}</Text>
    <View style={rowStyles.right}>
      <Text style={rowStyles.value}>
        {value} <Text style={rowStyles.unit}>{unit}</Text>
      </Text>
      <Text style={[rowStyles.status, { color: statusColor[status] }]}>
        [{status}]
      </Text>
    </View>
  </View>
);

// ── Diagnosis View ────────────────────────────
const DiagnosisView: React.FC = () => (
  <View style={styles.cardSection}>
    <Text style={styles.sectionLabel}>INFORME CLÍNICO · 14 MAY 2026</Text>

    <Text style={diagStyles.body}>
      El perfil hematológico actual refleja un estado de salud basal dentro de márgenes fisiológicos normales para un deportista de competición con volumen de entrenamiento moderado-alto.
    </Text>

    <Text style={diagStyles.body}>
      Los valores de hemoglobina (14,2 g/dL) y hematocrito estimado sitúan la capacidad de transporte de oxígeno en rango funcional, sin indicadores de anemia ferropénica ni eritrocitosis compensatoria relevante.
    </Text>

    <Text style={diagStyles.body}>
      El nivel de cortisol en fase matinal (21,4 μg/dL) se aproxima al límite superior del rango de referencia. Este hallazgo es coherente con la acumulación de carga de entrenamiento registrada en las últimas cuatro semanas y no implica patología, aunque sugiere implementar un protocolo estructurado de reducción de carga en el próximo microciclo.
    </Text>

    <View style={diagStyles.divider} />

    <Text style={[diagStyles.body, { color: COLORS.textSecondary }]}>
      RECOMENDACIONES:
    </Text>

    {[
      'Reducir volumen de entrenamiento en 20–25 % durante 7 días.',
      'Exposición solar controlada (20 min/día) para normalización de vitamina D.',
      'Control glucémico postprandial en próxima analítica trimestral.',
      'Mantener protocolo de sueño de 8 h para soporte del eje HPA.',
    ].map((rec, i) => (
      <View key={i} style={diagStyles.recRow}>
        <Text style={diagStyles.recIndex}>{String(i + 1).padStart(2, '0')}</Text>
        <Text style={diagStyles.recText}>{rec}</Text>
      </View>
    ))}

    <View style={diagStyles.divider} />
    <Text style={[diagStyles.body, { color: COLORS.textSecondary, fontSize: TYPOGRAPHY.size.xs }]}>
      Este informe ha sido generado a partir de datos introducidos manualmente. No sustituye el criterio médico profesional.
    </Text>
  </View>
);

// ─────────────────────────────────────────────
const styles = StyleSheet.create({
  content: {
    paddingBottom: SPACING.section,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: SPACING.base,
    paddingTop: SPACING.xl,
    paddingBottom: SPACING.lg,
  },
  title: {
    fontSize: TYPOGRAPHY.size.xs,
    color: COLORS.textSecondary,
    letterSpacing: 1.4,
    fontWeight: '600',
  },
  toggle: {
    flexDirection: 'row',
    borderWidth: 1,
    borderColor: COLORS.cardBorder,
    borderRadius: RADIUS.sm,
    overflow: 'hidden',
  },
  toggleBtn: {
    paddingVertical: SPACING.xs,
    paddingHorizontal: SPACING.sm,
  },
  toggleBtnActive: {
    backgroundColor: COLORS.card,
  },
  toggleText: {
    fontSize: TYPOGRAPHY.size.xs,
    letterSpacing: 1,
    color: COLORS.textSecondary,
    fontWeight: '600',
  },
  toggleTextActive: {
    color: COLORS.textPrimary,
  },
  cardSection: {
    marginHorizontal: SPACING.base,
    backgroundColor: COLORS.card,
    borderWidth: 1,
    borderColor: COLORS.cardBorder,
    borderRadius: RADIUS.md,
    overflow: 'hidden',
  },
  marginTop: {
    marginTop: SPACING.sm,
  },
  sectionLabel: {
    fontSize: TYPOGRAPHY.size.xs,
    color: COLORS.textSecondary,
    letterSpacing: 1.4,
    fontWeight: '600',
    padding: SPACING.md,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.divider,
  },
  rowDivider: {
    height: 1,
    backgroundColor: COLORS.divider,
    marginHorizontal: SPACING.md,
  },
  summaryGrid: {
    flexDirection: 'row',
    padding: SPACING.base,
  },
  summaryCell: {
    flex: 1,
    alignItems: 'center',
  },
  summaryCount: {
    fontSize: TYPOGRAPHY.size.display,
    fontWeight: '700',
    letterSpacing: -1,
  },
  summaryLabel: {
    fontSize: TYPOGRAPHY.size.xs,
    color: COLORS.textSecondary,
    letterSpacing: 0.8,
    marginTop: SPACING.xs,
    textAlign: 'center',
  },
});

const rowStyles = StyleSheet.create({
  row: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: SPACING.md,
    paddingHorizontal: SPACING.md,
  },
  right: {
    alignItems: 'flex-end',
    gap: 2,
  },
  metric: {
    fontSize: TYPOGRAPHY.size.sm,
    color: COLORS.textSecondary,
    flex: 1,
  },
  value: {
    fontSize: TYPOGRAPHY.size.base,
    fontWeight: '700',
    color: COLORS.textPrimary,
  },
  unit: {
    fontSize: TYPOGRAPHY.size.xs,
    color: COLORS.textSecondary,
    fontWeight: '400',
  },
  status: {
    fontSize: TYPOGRAPHY.size.xs,
    fontWeight: '600',
    letterSpacing: 0.4,
  },
});

const diagStyles = StyleSheet.create({
  body: {
    fontSize: TYPOGRAPHY.size.base,
    color: COLORS.textPrimary,
    lineHeight: TYPOGRAPHY.lineHeight.clinical,
    fontWeight: '400',
    padding: SPACING.md,
    paddingBottom: 0,
  },
  divider: {
    height: 1,
    backgroundColor: COLORS.divider,
    marginHorizontal: SPACING.md,
    marginVertical: SPACING.base,
  },
  recRow: {
    flexDirection: 'row',
    paddingHorizontal: SPACING.md,
    paddingTop: SPACING.sm,
    gap: SPACING.sm,
  },
  recIndex: {
    fontSize: TYPOGRAPHY.size.xs,
    color: COLORS.sport,
    fontWeight: '700',
    fontFamily: 'Menlo',
    letterSpacing: 0,
    marginTop: 2,
    minWidth: 20,
  },
  recText: {
    flex: 1,
    fontSize: TYPOGRAPHY.size.sm,
    color: COLORS.textPrimary,
    lineHeight: TYPOGRAPHY.lineHeight.clinical,
  },
});
