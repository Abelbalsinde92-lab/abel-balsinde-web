// ─────────────────────────────────────────────
//  HomeHeader — "Hola, Abel" + Fecha en gris
//  Fondo negro puro, sin decoración
// ─────────────────────────────────────────────
import React, { useMemo } from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { COLORS, TYPOGRAPHY, SPACING } from '../constants/theme';

const formatDate = (): string => {
  const now = new Date();
  return now.toLocaleDateString('es-ES', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  });
};

export const HomeHeader: React.FC = () => {
  const date = useMemo(() => formatDate(), []);

  return (
    <View style={styles.container}>
      <Text style={styles.greeting}>Hola, Abel.</Text>
      <Text style={styles.date}>{date}</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: COLORS.bg,
    paddingHorizontal: SPACING.base,
    paddingTop: SPACING.xl,
    paddingBottom: SPACING.lg,
  },
  greeting: {
    fontSize: TYPOGRAPHY.size.xxl,
    fontWeight: '700',
    color: COLORS.textPrimary,
    letterSpacing: -0.5,
    marginBottom: SPACING.xs,
  },
  date: {
    fontSize: TYPOGRAPHY.size.sm,
    color: COLORS.textSecondary,
    letterSpacing: 0.2,
    textTransform: 'capitalize',
  },
});
